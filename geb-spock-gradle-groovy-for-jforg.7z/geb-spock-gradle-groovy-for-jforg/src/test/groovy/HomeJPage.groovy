/**
 * Created by nandha on 11/19/2018.
 */
import geb.Page
import org.openqa.selenium.By

class HomeJPage extends LoginPage {
    static url=''

    static at = { title.startsWith("Artifactory") }
    static content = {
        // tile1 {$(".home-header-happily.ng-binding.ng-scope")}
        // quicksearch{$("input#quick")}
        quicksearchhome{$(By.xpath(".//*[@id='quick']"))}
        quicksearchinput{$("input#quick")}
        quicksearchclick{$(By.xpath("//span[@ng-click='ctrl.search()']"))}
        quicksearchnotfound{$(By.xpath("//div[contains(text(),'No artifacts found. You can broaden your search by using the * and ? wildcards')]")).value()}
    }

    /*
    //static at = {title == "Artifactory"}

    static at = {$("h1").text() == "   Artifactory is happily serving 1 artifact"}

    static content = {
       // tile1 {$(".home-header-happily.ng-binding.ng-scope")}
       // quicksearch{$("input#quick")}
        quicksearchhome{$(By.xpath("//a[@id='search']"))}
        quicksearchinput{$("input#quick")}

    }
    */
}
