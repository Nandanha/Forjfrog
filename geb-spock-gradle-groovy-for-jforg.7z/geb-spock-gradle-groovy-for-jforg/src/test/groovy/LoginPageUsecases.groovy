/**
 * Created by nandha on 11/19/2018.
 */


import geb.spock.GebReportingSpec
import geb.waiting.Wait
import org.openqa.selenium.By


class LoginPageUsecases extends GebReportingSpec {

    def "Log in to JfrogArtifactory Core"() {
        given:
        to LoginPage
        waitFor { loginButton.isDisplayed() }

        /*
        when:
        //invalid username and password
        username.value("test")
        password.value("pwww")
        loginButton.click()

        then: "Invalid user password so stays back at login page"
        assert $("h3").text() == "Welcome to JFrog Artifactory!"
        Thread.sleep(5000);
*/
        when:
        //valid username and password
        username.value("admin")
        password.value("password")
        loginButton(to: HomeJPage).click()
        Thread.sleep(5000);

        then: "Check at home page"
        assert $("h1").text() == "Artifactory is happily serving 1 artifact"
        at HomeJPage

    }

    def "Quick Search Post login"() {
        when:
        at HomeJPage

        then:
        quicksearchhome.click();

        //invalid data being sent to validate
        quicksearchinput.value("test");
        Wait.DEFAULT_TIMEOUT
        Thread.sleep(5000);
        quicksearchclick.click();
        Wait.DEFAULT_TIMEOUT
        Thread.sleep(5000);
        assert $("div", text: contains("0"));

    }
}
