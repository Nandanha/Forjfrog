/**
 * Created by nandha on 11/19/2018.
 */
import geb.Page
import org.openqa.selenium.By

class LoginPage extends Page {

    static at = { title.startsWith("") }

    static content = {

        loginButton{$("#login")}
        password{$("input#password")}
        username{$("input#user")}
        welcomemessage{By.cssSelector("div.login-inner.ng-scope > h3")}
        quicksearch{$("input#quick")}
        invalidmsg{$("div[ng-if=Login.errorMessage]")}

    }
}